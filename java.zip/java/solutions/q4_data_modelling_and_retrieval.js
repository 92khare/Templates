// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast


// Write your code here

const fruitArray=[{name :'Apple',color:'red',pricePerKg:30},{name :'Grapes',color:'green',pricePerKg:30},{name :'Orange',color:'orange',pricePerKg:40},
{name :'Mango',color:'yellow',pricePerKg:100},{name :'Guava',color:'green',pricePerKg:35},{name :'Litchi',color:'red',pricePerKg:55}];

function getInfo(fruitName){

    for(var i=0;i<fruitArray.length;i++){
        if(fruitname.toLowerCase()===fruitArray[i].name.toLowerCase()){
            return fruitArray[i];
        }
    }
}

getInfo()